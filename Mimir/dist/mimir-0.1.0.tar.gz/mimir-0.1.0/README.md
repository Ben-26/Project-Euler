# Function docs 

## is_prime(x)
Returns a boolean, true if x is prime and false otherwise