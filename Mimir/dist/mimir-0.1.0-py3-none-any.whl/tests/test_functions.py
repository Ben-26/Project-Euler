import mimir

def test_is_prime():
    assert mimir.is_prime(5) == True
